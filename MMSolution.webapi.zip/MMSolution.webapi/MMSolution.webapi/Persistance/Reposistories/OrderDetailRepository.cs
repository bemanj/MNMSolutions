﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MMSolution.webapi.Core.Domain;
using MMSolution.webapi.Core.Repositories;
using MMSolution.webapi.Models;

namespace MMSolution.webapi.Persistance.Reposistories
{
    public class OrderDetailRepository : IOrderDetail
    {
        private  MNMSolutionsDevDBEntities1 db = null;



        public OrderDetailRepository()
        {
            this.db = new MNMSolutionsDevDBEntities1();
        }
        public void Insert(Core.Domain.OrderDetail d)
        {
          //  db.usp_OrderDetail_Insert(d);
            using (var context = new MNMSolutionsDevDBEntities1())
            {
                 context.usp_OrderDetail_Insert
            }
        }
    }
}