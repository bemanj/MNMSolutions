﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MMSolution.webapi.Core.Domain;

namespace MMSolution.webapi.Core.Repositories
{
   public interface IOrderDetail 
    {
        void Insert(OrderDetail d);

    }
}
