﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebAPI.MMSolution.Core;
using WebAPI.MMSolution.Core.InterfaceRepositories;
using WebAPI.MMSolution.Models;
using WebAPI.MMSolution.Persistence.Reposistories;

namespace WebAPI.MMSolution.Persistence
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly MNMSolutionsDevDBEntities _context;

        public UnitOfWork(MNMSolutionsDevDBEntities context)
        {
            _context = context;
            OrderDetails = new OrderDetailRepository(_context);
        }
        public IOrderDetailRepository OrderDetails { get; set; }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}